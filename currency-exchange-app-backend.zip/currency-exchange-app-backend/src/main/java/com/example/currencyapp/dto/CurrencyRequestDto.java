package com.example.currencyapp.dto;

//FOR FUTURE DEVELOPMENT, NOT USED BECAUSE THERE IS NO DATA TO PROTECT
public class CurrencyRequestDto { }
